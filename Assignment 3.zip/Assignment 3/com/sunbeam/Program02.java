package com.sunbeam;

public class Program02 {

	public static void main(String[] args) {
		Invoice i1 = new Invoice("100","good",5,2000);
		i1.display();
	}

}
